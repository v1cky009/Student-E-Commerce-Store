<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>

    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-image: url('https://images.unsplash.com/photo-1499159058454-75067059248a?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGNvbnRhY3QlMjB1c3xlbnwwfHwwfHx8MA%3D%3D');
            background-size: cover;
            font-family: sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            flex: 1;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 10px;
        }

        .label {
            display: block;
            margin-bottom: 5px;
        }

        .input {
            background-color: aliceblue;
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
        }

        .textarea {
            background-color: aliceblue;
            width: 100%;
            height: 100px;
            padding: 10px;
            border: 1px solid #ccc;
        }

        .button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        .footer {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>StudCart</h1>
        <h2>Contact Us</h2>
    </div>

    <form action="#">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="input" id="name" name="name" placeholder="Enter your name">
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="input" id="email" name="email" placeholder="Enter your email">
        </div>

        <div class="form-group">
            <label for="message">Message:</label>
            <textarea class="textarea" id="message" name="message" placeholder="Enter your message"></textarea>
        </div>

        <div class="form-group">
            <button class="button">Send</button>
        </div>
    </form>
</div>
<footer class="footer">
    <!-- Add links to important pages -->
    <p>©Studcart.inc</p>
</footer>
</body>
</html>
