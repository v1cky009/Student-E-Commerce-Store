<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Studzie - Your Ultimate Shopping Destination</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #444;
            padding: 10px 20px;
            color: #fff;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
            font-size: 1.1em;
        }

        .search-bar {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .search-bar input[type="text"] {
            padding: 10px;
            border-radius: 5px;
            border: none;
            margin-right: 10px;
            width: 70%;
        }

        .search-bar button {
            padding: 10px;
            border-radius: 5px;
            border: none;
            background-color: #555;
            color: #fff;
            cursor: pointer;
        }

        .product-grid {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            padding: 20px;
        }

        .product-card {
            flex: 0 0 calc(25% - 20px);
            margin: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            background-color: #fff;
        }

        .product-card:hover {
            transform: scale(1.05);
        }

        .product-image {
            height: 200px;
            width: 100%;
            object-fit: cover;
            border-radius: 8px;
        }

        .product-info {
            text-align: center;
        }

        .product-title {
            font-size: 1.4em;
            margin-bottom: 0.5em;
            color: #333;
        }

        .product-description {
            font-size: 1.1em;
            margin-bottom: 1em;
            color: #666;
        }

        .product-price {
            font-size: 1.4em;
            font-weight: bold;
            color: #e44d26;
        }

        .add-to-cart-btn {
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1em;
        }

        .footer {
            background-color: #444;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
<header>
    <h1>Welcome to Studzie - Your Ultimate Shopping Destination</h1>
</header>

<nav class="navbar">
    <div>
        <img src="https://png.pngtree.com/png-clipart/20210425/original/pngtree-professional-polygon-logo-png-image_6248565.jpg" alt="Studzie Logo" height="40">
        <em>Studzie</em>
    </div>
    <div>
        <a href="estoreconn">Home</a> |
        <a href="{{ route('products') }}">Products</a> |
        <a href="{{ url('/contact') }}">Contact Us</a> |
        <a href="{{url('/register')}}">Register</a> |
        <a href="{{ route('sell.form') }}">Sell</a> |
        <a href="{{ route('cart') }}">Cart</a>
    </div>

    <form class="search-bar">
        <input type="text" name="search" placeholder="Search...">
        <button type="submit">Search</button>
    </form>
</nav>

@if($products->isEmpty())
   <p>No products available.</p>
@else
   <div class="product-grid">
       @foreach($products as $product)
           <div class="product-card">
               <img src="{{ asset($product->picture) }}" alt="{{ $product->name }}" class="product-image">
               <div class="product-info">
                  <h2 class="product-title">{{ $product->name }}</h2>
                  <p class="product-description">{{ $product->description }}</p>
                  <div class="product-price">${{ $product->price }}</div>
                  <form action="/add-to-cart/{{ $product->id }}" method="get">
                      @csrf
                      <button type="submit" class="add-to-cart-btn">Add to Cart</button>
                  </form>
               </div>
           </div>
       @endforeach
   </div>
@endif

<footer class="footer">
    <p>&copy; Studzie.inc</p>
</footer>
</body>
</html>
