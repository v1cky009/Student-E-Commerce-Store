<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You Page</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        .thank-you-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        .thank-you-container h2 {
            color: #4caf50;
            margin-bottom: 20px;
        }

        .additional-content {
            margin-top: 20px;
            font-size: 1.2em;
            color: #333;
        }

        .continue-shopping-btn {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .continue-shopping-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="thank-you-container">
        <h2>Thank You for Your Purchase!</h2>
        <!-- Additional content or order details can be displayed here -->
        <p class="additional-content">Your order has been successfully processed. We appreciate your business!</p>

        <!-- You can include additional content here such as order details, tracking information, etc. -->

        <a href="{{ route('products') }}" class="continue-shopping-btn">Continue Shopping</a>
    </div>
</body>
</html>
