<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

use App\Http\Controllers\Auth\LoginController;

Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);


Route::get('/estoreconn', function(){
    return view('estoreconn');
});
Route::get('/contact', function () {
    return view('contact');
});
use App\Http\Controllers\AuthController;
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);

// routes/web.php

use App\Http\Controllers\ProductController;

Route::get('/sell/form', [ProductController::class, 'sellForm'])->name('sell.form');
Route::post('/sell', [ProductController::class, 'store'])->name('sell');
Route::get('/products', [ProductController::class, 'products'])->name('products');


use App\Http\Controllers\CartController;

// Correct
Route::get('/add-to-cart/{id}', [CartController::class, 'addToCart'])->middleware('web');
Route::get('/buy-now', [CartController::class, 'buyNow'])->middleware('web');
Route::get('/cart', [CartController::class, 'viewCart'])->name('cart');

