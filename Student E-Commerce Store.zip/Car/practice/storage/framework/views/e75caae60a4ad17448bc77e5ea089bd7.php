<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #333;
            height: 80px;
            color: #fff;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }

        /* Add styles for the search bar */
        .search-bar {
            display: flex;
            align-items: center;
            margin-bottom: 3px;
        }

        .search-bar input[type="text"] {
            padding: 10px;
            border-radius: 5px;
            border: none;
            margin-right: 10px;
            width: 100%;
        }

        .search-bar button {
            padding: 10px;
            border-radius: 5px;
            border: none;
            background-color: #333;
            color: #fff;
        }
        /* Add styles for the footer */
        .footer {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }

        #div1 {
            width: 1px;
            height: 100px;
            padding: 0 1%;
            text-align: center;
            font-size: 38px;
            font-family: sans-serif;
            margin-bottom: 15px;
            margin-top: 13px;
            display: flex;
            align-items: center;
        }

        #div1 img {
            height: 50px;
            width: 50px;
            margin-right: 5px;
            margin-bottom: 1px;
        }

        #ctr {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 702px;
            font-size: 15px;
            font-family: sans-serif;
            font-weight: 500;
            margin-bottom: 17px;
            margin-top: 15px;
            margin-left: 175px;
            padding: 7px;
            border-radius: 10px;
            background-color: #333;
            color: #fff;
        }
        .footer {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }
        .cart-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 20px;
            max-width: 600px;
            margin: auto;
        }

        .cart-item {
            border-bottom: 1px solid #ddd;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .cart-item img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 5px;
            margin-right: 10px;
        }

        .cart-item-details {
            flex-grow: 1;
        }

        .cart-item-details h3 {
            margin: 0;
        }

        .cart-total {
            margin-top: 20px;
            font-size: 1.2em;
            font-weight: bold;
        }

        .buy-now-btn {
            display: block;
            margin-top: 20px;
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            text-align: center;
        }

        .buy-now-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<header class="header">
    <!-- Add a navigation bar -->
    <nav class="navbar">
        <div id="div1">
            <img src="https://png.pngtree.com/png-clipart/20210425/original/pngtree-professional-polygon-logo-png-image_6248565.jpg">
            <em>Studzie</em>
        </div>
        <div id="ctr">
            <a href="estoreconn">Home</a>
            <a href="#">|</a>
            <a href="<?php echo e(route('products')); ?>">Products</a>
            <a href="#">|</a>
            <a href="<?php echo e(url('/contact')); ?>">Contact Us</a>
            <a href="#">|</a>
            <a href="<?php echo e(url('/register')); ?>">Register</a>
            <a href="#">|</a>
            <a href="<?php echo e(route('sell.form')); ?>">Sell</a>
            <a href="#">|</a>
            <a href="<?php echo e(route('cart')); ?>">Cart</a>
        </div>

        <form class="search-bar">
            <input type="text" name="search" placeholder="Search...">
            <button type="submit">Search</button>
        </form>
    </nav>
</header>
    <!-- Display cart items -->
    <div class="cart-container">
    <?php if(empty($cart)): ?>
            <h2>Cart is Empty</h2>
        <?php else: ?>
        <h2>Shopping Cart</h2>
        <!-- Loop through cart items and display each item -->
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cart-item">
                <img src="https://source.unsplash.com/50x50/?<?php echo e($item['name']); ?>" alt="<?php echo e($item['name']); ?>">
                <div class="cart-item-details">
                    <h3><?php echo e($item['name']); ?></h3>
                    <p>Quantity: <?php echo e($item['quantity']); ?> - Price: $<?php echo e($item['price'] * $item['quantity']); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Buy Now link -->
        <a href="/buy-now" class="buy-now-btn">Buy Now</a>
        <?php endif; ?>
    </div>

</body>
<footer class="footer">
        <!-- Add links to important pages -->
        <p>©Studcart.inc</p>
    </footer>
</html><?php /**PATH D:\Car\practice\resources\views/cart.blade.php ENDPATH**/ ?>