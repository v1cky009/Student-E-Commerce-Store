<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Studzie - Study smart, shop smarter!</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha384-hVFkv1Cq01T65t9DHD1LmPkA0qs5Uv2FsB1EZ35Kb7qVv6i1t4QZoQc3NwPrgyDg" crossorigin="anonymous">
  <style>
    body {
      font-family: 'Arial', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f8f8f8;
    }

    header {
      text-align: center;
      padding: 5px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    }

    header img {
      max-width: 70px;
    }

    header h1 {
      font-size: 24px;
      margin-top: 7px;
      color: #333;
    }

    form {
      max-width: 400px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      box-sizing: border-box;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: bold;
    }

    input {
      width: 100%;
      padding: 10px;
      margin-bottom: 16px;
      box-sizing: border-box;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    button {
      background-color: #007bff;
      color: #fff;
      padding: 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      width: 100%;
      display: inline-block;
    }

    button:hover {
      background-color: #0056b3;
    }

    .progress {
      height: 10px;
      background-color: #eee;
      border-radius: 5px;
      margin-top: 10px;
      overflow: hidden;
    }

    .progress-bar {
      height: 100%;
      background-color: #007bff;
      width: 30%; /* Adjust this value based on your progress */
    }

    p {
      margin-top: 20px;
      font-size: 14px;
      color: #555;
    }

    a {
      color: #007bff;
      text-decoration: none;
    }

    .social-login {
      margin-top: 20px;
    }

    .social-login a {
      display: block;
      margin-bottom: 10px;
      padding: 10px;
      text-align: center;
      background-color: #eee;
      color: #555;
      border-radius: 4px;
      text-decoration: none;
    }

    .social-login i {
      margin-right: 10px;
    }

    footer {
      text-align: center;
      padding: 10px;
      background-color: #fff;
      position: fixed;
      bottom: 0;
      width: 100%;
      box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);
    }
    #pp{
        text-align: center;
    }

  </style>
</head>
<body>
  <header>
    <img src="https://png.pngtree.com/png-clipart/20210425/original/pngtree-professional-polygon-logo-png-image_6248565.jpg" alt="Studzie Logo">
    <h1>STUDCART</h1>
    <h2>Unlock your student discounts!</h2>
  </header>
  <form method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo csrf_field(); ?>

    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Your awesome name" required autofocus>
    </div>

    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Your academic email" required>
    </div>

    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" name="password" required placeholder="Super secret!">
    </div>

    <div class="form-group">
      <label for="password_confirmation">Confirm Password:</label>
      <input type="password" name="password_confirmation" required placeholder="Just to be sure">
    </div>

    <button type="submit">Get your study essentials!</button>

    <p id="pp">Already a Studzie? <a href="/login">Log in here!</a></p>

    <p>By registering, you agree to our <a href="/terms">Terms and Conditions</a>.</p>
  </form>

  <footer>
    <p>@StudCart</p>
  </footer>
</body>
</html>
<?php /**PATH D:\Car\practice\resources\views/auth/register.blade.php ENDPATH**/ ?>