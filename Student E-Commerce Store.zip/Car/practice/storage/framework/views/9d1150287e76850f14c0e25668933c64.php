<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sell at STUDCART</title>
    <style>
        header {
   text-align: center;
   padding: 20px 0;
}

.success-message {
   color: green;
}

form {
   width: 50%;
   margin: 0 auto;
}

form label {
   display: block;
   margin-bottom: 10px;
}

form input, form textarea {
   width: 100%;
   padding: 10px;
   margin-bottom: 20px;
}

form button {
   padding: 10px 20px;
   background-color: #007BFF;
   color: white;
   border: none;
   cursor: pointer;
}
.footer {
    background-color: #333;
    color: #fff;
    padding: 10px;
    text-align: center;
    margin-top: auto; /* Push the footer to the bottom */
}
body {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    margin: 0;
    padding: 0;
    font-family: sans-serif;
}
    </style>
</head>
<body>
    <!-- resources/views/sell.blade.php -->

<header>
    <h1>STUDCART</h1>
   <h2>Sell a Product</h2>
</header>

<?php if(session('success')): ?>
   <section class="success-message">
       <p><?php echo e(session('success')); ?></p>
   </section>
<?php endif; ?>

<main>
<form action="<?php echo e(route('sell')); ?>" method="post" enctype="multipart/form-data">
       <?php echo csrf_field(); ?>
       <label for="name">Product Name:</label>
       <input type="text" id="name" name="name" required>
       <label for="description">Product Description:</label>
       <textarea id="description" name="description" required></textarea>
       <label for="price">Product Price:</label>
       <input type="number" id="price" name="price" required>
       <input class="form-control"id="picture"type="file" name="file" />
       <button type="submit">Sell Product</button>
   </form>
</main>
<footer class="footer">
    <!-- Add links to important pages -->
    <p>©Studcart.inc</p>
</footer>
</body>
</html><?php /**PATH D:\Car\practice\resources\views/sell.blade.php ENDPATH**/ ?>