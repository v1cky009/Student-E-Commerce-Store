<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Studzie - Online Learning Platform</title>
    <style>
        /* Add styles for the navigation bar */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #333;
            height: 80px;
            color: #fff;
            margin-top: 1px;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }

        /* Add styles for the search bar */
        .search-bar {
            display: flex;
            align-items: center;
            margin-bottom: 3px;
        }

        .search-bar input[type="text"] {
            padding: 10px;
            border-radius: 5px;
            border: none;
            margin-right: 10px;
            width: 100%;
        }

        .search-bar button {
            padding: 10px;
            border-radius: 5px;
            border: none;
            background-color: #333;
            color: #fff;
        }
        /* Add styles for the footer */
        .footer {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
            margin-right: 20px;
        }

        #div1 {
            width: 1px;
            height: 100px;
            padding: 0 1%;
            text-align: center;
            font-size: 38px;
            font-family: sans-serif;
            margin-bottom: 15px;
            margin-top: 13px;
            display: flex;
            align-items: center;
        }

        #div1 img {
            height: 50px;
            width: 50px;
            margin-right: 5px;
            margin-bottom: 1px;
        }

        #ctr {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 702px;
            font-size: 15px;
            font-family: sans-serif;
            font-weight: 500;
            margin-bottom: 17px;
            margin-top: 15px;
            margin-left: 175px;
            padding: 7px;
            border-radius: 10px;
            background-color: #333;
            color: #fff;
        }
            .slider-container {
            max-width: 1000px;
            margin: auto;
            overflow: hidden;
            position: relative;
            margin-top: 20px;
        }

        .slides {
            display: flex;
            transition: transform 1s ease-in-out;
        }

        .slide {
            min-width: 100%;
        }

        .slide img {
            width: 100%;
            height: 500px;
        }
    </style>
    <script>
        function reloadPage() {
            location.reload();
        }
    </script>
</head>
<body>
<header class="header">
    <!-- Add a navigation bar -->
    <nav class="navbar">
        <div id="div1">
            <img src="https://png.pngtree.com/png-clipart/20210425/original/pngtree-professional-polygon-logo-png-image_6248565.jpg">
            <em>Studzie</em>
        </div>
        <div id="ctr">
            <a href="#" onclick="reloadPage()">Home</a>
            <a href="#">|</a>
            <a href="<?php echo e(route('products')); ?>">Products</a>
            <a href="#">|</a>
            <a href="<?php echo e(url('/contact')); ?>">Contact Us</a>
            <a href="#">|</a>
            <a href="<?php echo e(url('/register')); ?>">Register</a>
            <a href="#">|</a>
            <a href="<?php echo e(route('sell.form')); ?>">Sell</a>
            <a href="#">|</a>
            <a href="<?php echo e(route('cart')); ?>">Cart</a>
        </div>

        <form class="search-bar">
            <input type="text" name="search" placeholder="Search...">
            <button type="submit">Search</button>
        </form>
    </nav>
</header>

<main class="main">
    <!-- Add an image slider for online study-related images -->
    <div class="slider-container">
        <div class="slides" id="image-slider">
            <div class="slide">
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBISEhIREhUYEhEREREREREREhIREQ8RGBQZGRgUGBgcIS4lHB4rIRgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHBISHjEkISExNDQ0NDQ0MTQ0NDE0NDQ0NDQ0NDE0NDQxNDQ0MTQ0NDQ0NDQ0NDQ0MTQ0PzE0NDQ/NP/AABEIALcBEwMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAACAAEDBQYEB//EAEkQAAIBAgIHAwcIBggHAQAAAAECAAMRBBIFBiExUVKRE0FhFCIyQnGBoRUWU2KxwdHwByNykqLhQ2NzgoOTo7IzRFTC0tPxJf/EABkBAQEBAQEBAAAAAAAAAAAAAAABAgMEBf/EACsRAAICAQMDAwQCAwEAAAAAAAABAhESAyFREzFBBGGRFCKBsTJCYnGhUv/aAAwDAQACEQMRAD8A8fiiilIKKKKQDRR4oAMUeNBR4oooA8eNFAHnbo9bkThltodbkTS7mJuol5hsPunb5JfunRhkGyWCIJ1SPnyk7KI4LwjeR+E0HZiP2QlomTM/5F4ReReE0HZLEaQihkzPeSeEmTD2G6XBpCRVUFooZMxemxtlFeaHWAbZnZxl3Pfo/wAR40UUydRoo8UAaKPFAGjxRoA94rxooA94o0UAeKbOtoTDnc6+6cFXV9D6Dge0j8Zh6sOTqvT6r8MzcUvhqy30qD3xfNs/TJ+ffJ1ocmvptbj9FDFL4at/16dP5wxqyvfiE6fzk60Of2PpdXj9GdimkGrKf9Sn7v8AOC2rdMf8wp/uydeHJr6TV4/6jOxS/bVpiLpURvA7Jw1tC103rccVN5qOrB9mYfp9WPdMro8N6Dr6Ske0QQh4Totzk1XcaW+hfSEqspltoZds0u5y1P4s2OG7p3pODDDdO9J2R81hR7xohKQOMYgImNt8GgTOXFVAoJJtObSWmKdMHbczI43ST1mAJspIFvfMykkdYaLl/ol0u4qHzdsqfJTPU9E6v0eyQstyQCdk7zoChyjoJ5nNt9j6UNKMY1Z4+MIYxwpnsHyBQ5R0EA6Aoco6CTJ8GumuTyHyUxeSmeuHV+hyjoIDavUOQdIyfAwXJ5L5MYvJjPVW1coco6SJtWqHL8Jc3wTBcnlpomD2JnqDas0OWRNqxQ4Rl7Ex9zzTsjG7Iz0dtV6PCRNqvRjImJ552Zjzf/Nej4x5chQXzc+sI3zc+sJpSU4jrGunEdZwUYHpvUM6NXfrCP8AN36wmiAX8mPlWWoFvUM8NXhzCONXxzCaHKsfKsVAXqGfXV9eYSRNX15gZfBV8I6BfCTGAvV9ygfQY7jb2QG0PVX0Wv4S/KAH8JMpEy9ODI9XVj2bMdicHUHpoG90rK2Gp+smX3T0Ct7LyoxKITYp8JFp1/FlXqG9ppP8GNfRtNvRa3hOrAaPynYQZcVtHUzuW0520ey7VM6RlqR9zE46M1VUdtBCJ2pOHChgPOnchnthJtW0fH14RhKouwo4ivEDNnAcTN6w6UZPMXeZpGawv4TEaVVq1Rgik5e8CYm6R30I5SKas5Y3Y3MFD5y+DD7Z3nRdXkPSQvoqtyke6cLR9BRfB7Hod0alT84eiO8TvyrxHWeIU6WLT0XdbbgGIEm7bHfSv+9M7G1lwe0ZRxHWIoOInjAxOPH9K/WF5ZpD6V+sbFuXB7EUHEQTTHhPHxjNIfSP1hrjdI87y7EuXB66aY8JG1KeUjH4/neIaRx/O/SKRLlwepNRkbUZ5mNJY8eu3SL5Ux3O3SNhb4PSWpQGozzr5Wx3MekXyxjuJ6S7E+7g9C7GKeffLON4npFGxPu4O/tH5H6n8ZBiRWPoK6+2/wCM9BGDHAQHw4XeBPP0UjutSXLPNXfFrvdh7bwBiMXznrPSnwlNxZlB90q8VoBTtpm3h3Q9OvCOkdV+WzFjFYvmMfynGcx6y7xGjalPeuziJzZZze3hHeLb/syt8oxfMepjriMXzHqZZqs7MPgy2/YJNn4Rq2v7MqqWPxfG8vtG6ScL+sVi31QTOzDYRbhQJocNo8BRsHSaWkn7HKWq+1sz/wAqjkf92P8AKa99Jj7ppfIRwHSEuBXgOkq0WvLOTk2Zo6Rpn+ib92JsZTYWyFT4i01KYJeA6TO6dpBKgA2bJ209Nt02ebWm4xyRwPY7o6wBCnsisVR8vUk5yyqgrx7wI9po50xq7eY3sMbVagjK7EAksdsTpcEcRK6hTxFAnsz5pN7GYkrPT6eai3ZsamFW3ojpKnE4cX2ASixGt1amcjpcjhOOprk59ScqPcp32LfGYO4uBKs0yDa0FNbx6yE+6Ia2Uwb9kekw4Jm1qNHVRwFR9yyyw2gWPpbJVprsg3UyPdJhr2nIYUIjqM0NDQ1Nd4vOsYGmPVEyy69U+9D0j/PqnyHpNYomZpzg6fKIJwVPkHSZoa90eVukmXXvDcrdJaGRfHBU+UdIBwVPkHSUo16w3A9IjrvhfHoYomRbtg6fKILYOnyDpKn564Xx6RfPPCcT0ihkWfkdPlHSKVXzwwvExRQyNmrDjI66gjfPLE0zje5j0MmTSeM3sWPuM4OT4NqM34XyegF1HfHFZOI6zBNj8Q29W6NI+1q8r/xTOb4Oq0Zcr5PQWqUzsJBnHidG0am4gHwmJz1uD/xRZ8R9f+KRyvwbWlNdmvk1LaMWntzAiD2ijZeZjNiPr/GIdt3q3QzH4NKE/LRu9FlCb3E0VN1tvnldGvWXcj9DOkaUxHI/SVakl4K9GT/sj07tF4iP2qcR1nmK6Ur8j9I+IxlYhV85Cx33l6kuDMtBpXkj1Ba6cw6iZrWFc1TOGGUKb7ZU0EZUBdyTbjM7pJalR7I7W/aO2acpL2OPSk1dWi9TFU+aSDFU+YTLpoiofXk66GfnmlP3MPR9jR+U0+YRxiqfMJnRoV+eENDNzy5+5no+xofKafMIzYqnzCZrEaONNSxfcOMoHqVG9Em3hNRk35JLTS7o1ejdGpi6tRmNwDYCXqapUO8Tz/R+NxOHLGn62+dyayY4bz8JdhG47UbX5p0OEE6pUOEyK61Ywd0kGt2MHqiWolyfBqDqlQ4QTqhRma+d+L5RH+eOK5BFImT4NA2p9H8kyNtTaUpV1zxPegj/AD1r8ktIWyzfUyn3Srr6o23bYjrrW5JzPrZX5fhLSMtsirauOvq3nFU0QV3qZ3HWmt3r8JE+slQ70HSKQtle2AA7oPkS8J0vpon1BIflL6slC2P8miKSDSDHuEUlGr9jf4bR9Mdw+EsaeGpjuHwmEppivpD1k6ri/pD1nHqxPYvTvyzcrRTgvwkgopwHwmGVcX9IeslU4znk6sTa9N7m2FGnwHwhilT4D4TEBsZzx82M5/jJ1omvpf8AI3ApJyjoISUEJACi5IA2CYdPLOeWegjihiaXaNdA5LDjZSR8bSrVi3RmXpmk3l2PQG0dhaa+clzbfsJ9tjOFcNh19Vm272FP7llPrdpV8Pha1entqKFVSdoUsyrf3Xv7pg9EaGxeMoHFJjm7YlyKPaPmBBIAYhvMvbZ5trETat7nle23c9cp4DC1NnnIdm4Ux9qxtJ6s4SoqDIVcsqpUQ2ZTvJI9E7Ae6ZTU7F4t6LJi0dKtNgFeohQ1EI2HxIIIPumsbHf8G52h399qT/jI3WzLV7oLEav4JUAYFbd+YOze5wR8Jy/Jmjb/APAHtyj8ZW6ffFVKTjDMqVyVyM9iqjOM2wqR6N+7vmExWltL0cRSwj1aTVawUoQiFQGYgXOUW9E90vcOTWzbPU6Gr2j6hJVTt9QHIF9ltvxkL6nYbtRZnVMlyga/nX35jttM/q7U0irOcYUFuz7M0rfWzXt/dmr+UCXv3miOocyOgr5IqmrWCTeOr1Cfg4kJ0Fgj6tv83/2TOa96w1sFTp1KQVmqVCjdoGYWCk7LES10tjmo4WriFAL06LVArXylgt7G220fgflnQ2o+ErU2Rnc5tzU7oVFuDFgYGhtQMJSp5Khaq4Zhm9EEZiBsHfYbds59S9OVMThqeIqBVZ3dSqZsllYqN5PCX9bHkBwD5xdrHgDt++W62MuN7nDU1awFO6uov3emSPcGkQ1e0e4sLKx9Yq9umaY/WLWPF08bTwuGRKrPTVwtS4YucxPnZgALL3yFNbsTQq06ekMOKKubCqjXVdtr7yCBsvY3AmtxSNvW1JwlgwJsNr7rFe+3D4yZtScDb0WHjmkmExbWZCbq6sBt3Eg7pJUxzMi5dmZVN78QJMhiV9bU/RwB7idx85sp/e2yOnqXo4gDMxbvYWUH2A3tMjjNM4vDaUShWqlsNiSOyzJTGXPsAzBRucW37iCYdfWHFVdIjB4RlFOnYV2KhyMpu7XPC4UDmltikW+m9TcPQyspujG13tcNa/d7+kqfkDDnvHwmn1opmvg3pkkMj03VhvFmsfgTMB8jv3O/UzL1IruirRnLdFqdW6HEdRAbVmlzDqJWHRVXuqP1gnRtf6VusdWBehqFg2q9PuYdYDarJxE4Do/E/St1i8jxX0pl6kB0dTg621VXiJFU1ZVQWYiwF5AcPjBuqmRYmjjCpVqlwRtjqQ5J0dTgHyWlwEUr1wNUesYpxtcnfGX/AJNaluHwkgPhBHshX8J5z1hC3CELcIFzw+2OWPCSzSQYtC2SLOfzaIuZLLROGnTgH/WJ7T9hleWMEYnIQ3A3iMqaJKNxaL3WjH0qGFdq9Nq1FyKTqlgcrX2k3FvaDfaJj31PwtSgMZgsS1C6Goq1XUhTlvkLqQUIOw+lNfSxlDFUno1MrBlKsjG1x4d/vG6Z6p+jfCk3WtUVSb5bIxtwDW/Ge6ElXc+bOLvsdH6OdMVsTSqpWJc0SgSqxuxVwfNY95GXf4zRaRrZamHHNUcf6TH7pHo/BYbA0clPzFBzMzG7O3Mx7zMlrNrGhq0chuadXPYcMjKfg0zJpvY1GLxtm+EwendunMGOCUrdapml0LpunWQWYX9sHE6Ap1MZTxxqMHpBQEGXIQA2/v8AWM1GSMSiy5AkVJ/1xX+qH+8wMZj6dMEsw6iZKjrQnlZ84ZcgTwJDE2+MzJnRRG/S0P1GG/tX/wBk0mt2zR2K8MOw+wRtNaMoaSw4ps+WzB0dbEo1iN3eLE3EoK2pmOqItCrjy+HXL5uViSq7gQTt95Pdwm000jm003t3LT9HK/8A5tDxasf9Vx90uadbO9QX3Ow6bPunL21DR+GWkhAWkmVQxBY95Y+JJJ98y2g9ZkapULH0qjnbyliQZiT3s6RjtRHjRm0/THJS6fqnP/dJ/wBJmUYOmG9M11y8divmt4W+0SbSGrj4nFNjaGL7F2VVGRMxVQgUi+Yb7fGLDao/rlr43EtijTsyI4yoCNu0FjcbAbC17bb7p0TWzOTT3VGkwF0w9I1PTShTzk78wQXv8Z14F706e3+jThyiZTWzWJKdNqat57qVFt9zsv7J36B0zTdVUsNwttnNvc6qOxx/pKwavgxXvaphqiMjDf57KpX/AGn+6Iv0caNVML5UTmrYpmd2O0hFZgF95ux9vhLrTejqeMoNh2corlDmSxYZWDbj7JJorBphcPToB8y0lKhmsCdpJNvfN5fbRzx+6ybSp/UuOOUfxCZ7s526T0gr+ap2A9ZXCpfj0M803b2PbpRqO5IacjKQsw/+7IJA8OswdASkBlHGEVEBlEgANuMFrGO3skZvwgEeVYo9vzeKKFk6sOPwhCoBIgRHuJCh9oOEftPCBePMmhy54DpCDNxHQQQscIZGVBZWPfIzhbnaQfbaSZD+TJKK7ZCnINBUi2e1jvuhZTf3TtXDZRYPUt/a1PvM6nGyQlPaZvJryYxT8HFiNEJU2tnb9utUI6ZpX1NA0wdlNd+85iZo8Oo4SR03bBLk+RUeF8Gdw+r1MbQoXxUup6gzuGixuz1P8+t/5S2Cnw9wkLDzt5jJ8jFcL4Kmvq7Tba2Z/wBurUf7TOIat0b27NLe1/xmrAFoy0xfdDcvDZMY+UvgqMLohafos6eCVawHTNO1qbkWNSpbwqP+M6qy7omXZGTXkYp+EUWK1cR7liz3356tVh0LTiXVWle+UA8Q1QH4Ga5No3wAloyl4bGMeF8FFh9DZPQd18BVqfe0kraJZxZnqH/GqD7DLRvS/nGZgDv+EZPkuMeEZutqom0lQSe9ndj8THo6rKLZSU/YqVF++ajYYSC0uUuWZxjwvgp00Q6i3bVR/jP95iq6GZx51Wow4Gs4+yW9YG2/4CJCttp2+2W3yKXBVYbR4pDKCbXvtZmPtuZIUHiffadtZl4XnOSe4ASWUhyeEY35epkzA95+6RNb87YsURtfwHvg7e49BJCwkDueEATJ7eoH2QHsN9viYDVW4SFmPfFEJMy/kCKR3HjFKCZVkgWCDDE52bEqQwsYWjgiDQQtJABAz+EIOZlgNR4SVBIMxhoJEGdZOzfIiRCAEQIE0zIVISa0iV47VJQSSJiLwGYxgl98MHQKoG6EKhkaIBDJlsgNVrxHdAdpGzwDqR7CC9ThObPCpNNEEUJNzDCCNexhBpg0SKsm7pEsIzVmaOesTIk4zpYRgoiwQO+yRdqJ01EEi7ISNlQJqLI2ZZKaQgGmJCkRKRNl7jCNMQSglshE5XhImZeE6cojMoiwcufwjSfKIospzLJBIFeGHkBLeEDIw8IPMmiTNDVpCHhh4BKIYkQeGHkBOIQEgDmLOZSUdKgQ7icmYx9sCjoLiAasjymIU5bFEvbwTWiFKGKUWKIHcmOqEycUxDCy2SiNaYhBbSQCPlixRERHAh2itAHUxw8aCRBKCLxs0AiDAHd5GzwjAYSWUAuYDNDYSJhFloRaRs8MiCVlIR5jBZ4bLAZYAOaKNligHMqSRUgqYYMGiREhinAR4YeZsBBIapBDw1eQBqkkCCRh4g8m5SYIIeSQq8MVJCEgQRwkjDwg8AkCwgsj7SIVIsEwSPlkfaRu0lsEtorSLtIu0lslEwEUh7SLPAolJjSK8INLZSSNaBmj5pbMjkQSIxeCXiwIwTEzwM8hocwCIWaATIATBMItGJgAGA0NjImM0jI0UUUoOYCEBFFMmggIaiKKQBAQgIopAGBDCxRQUcCEBHikAo4iikIPHEUUAeEIooAo8UUoEYwMUUoHvFFFAGvGzRoppEYxMAtFFBQSYLNFFAANSLPFFNAFngl40UAEvALxRQZGzxRRQD//2Q==" alt="Online Study Image 1">
            </div>
            <div class="slide">
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYVFBcVFRUXGBcaGxsbHBoaHCEdHR0iHRsdHR0hHiAdICwkGyAqIBobJTYlKS4wMzMzHSI5PjsyPSwyMzABCwsLEA4QHhISHjQpJCkyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAAIDBQYBBwj/xABLEAACAQIEAgYFBwoFAwMFAQABAhEAAwQSITEFQQYTIlFhcTKBkaGxB0JSksHR8BQjU2JygqKy0uEVFjOT8UNUg2PC4kRzo+PyNP/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EACURAAICAgICAgMAAwAAAAAAAAABAhESIQMxQVEEEyJhcSMysf/aAAwDAQACEQMRAD8AG+TPFZevsNupDgd3zW9+Wt2K8z4ViOp4ojDRL42/+4s+5z7q9JBrin3Z2ITHWuYgx1dwAnI4zAakqxCt6gcreSUnFTogZShEhgVI8CINRZVGS4sotXGNtlbkdRlBfIG3YgD82vZIAWeQOgWO4bbuhOqNvrF7JSDbEZWQAMFMN2cu8bweVWPE+HX7rKRYt57ea2SHU59Q2bqyVFpiqq0ydGis9nu2r9y2LbBlgm2FNwxEg9lGAGp1kbnxowt9lqbitFrh+EhbTEsRkAABBjloJOgEHcnQgUKiDTtb/j1UFjMdcu3ABmQZQ055JBOhhT2piYMQPOibAyj0yW5yPdP/ADXPzxS6Or48pPciZcMpnX1yPedqTYVPoQe6R8achaBrr5x/zUqO8x79DXIn+ztaXoDGDTuYa8hp6zFE4bCa6OR7/tNTrcOx5/RifXFFWAYDFWy7Anae6Tzqrl4Ixg+yn46jdWCTI2948B3Vn4rYdJEHVJEan+s/ZWSZda6uOTaVnLOCTdEWG1the9ftmjsFogXmAf5yar8N6C+VHYbc+R+BNdKkcria8XhoJFSdbUNzBrvlEfs7eyKjtYIs2USPGYAHMwe7euFc1+Dtfx3FXY2xdEHzJ9pJqRmoxW6q2ECXD6OqknKJ3I7SjNlG3ugGleuqX6sXVOfKMrgqY7RP7wXWfLaK0zOegMGnq1DNbdQSBmUfOGgM6g9qOVR/lfeD+PKnnH2PCXoKxLTlHe6+45vspuHudhY7gPZoffVTxHihQKVGZp7I8dp010BNP4ZjZm2VIguc0AA9udB+9voPsr9hTotmeuM1RF65moEEBqcDQwNStfCK1z6Cs/1AWA9ZEeuhK3QpaVh35Kn6Va7Xkf8AiL/re012un6kc2ci34vPVWby6NauFJ5wTnT3l/ZXqeFvi4qXBs6qw/eAMeqY9Vee4nCGMTYO+VmAH0rZzafuZx660fQPGdZg7ak9q2zW45nXMvuY+yiX+o/JqQvL1VNaXKBJUMTp2oEa6aTmMcjINOwyDMwLKSsAgA6Trz8OdRY+8EGoBO48xB+FYyvwWkvJU8cxzWQ1zZtBlViM2uW2zTAHabKY3GknIBWdxDC3ceXEG2DdcntOwLEsxHzu0ZHjA0EUuK8V7YXUugzQfpNKrJ2hVzHKeZQ1RzDIhPY1PPUSCF+so8CNKqVpUVBJu2FphWjXss7ZxPzCR6LRyy6eebnFG2cNKgjQiQQeRG/nr7aezqwEmAY8xsQQYiZ184qaxJkHddIgiZ0DQY9L4hhyrjm5M7oKKYM0j0lnx5n1VPYcGRHiTP2VwOJg68yf70QirBMDXkdvx91ZNUto2Tt6ZEloFgATl8Y/Ao/hmHe64DMSonKmYwZM7DlP45UK79gkKQdgBEmSBPfprrQVi/etXEdJBDQGYNEtAOYCMw1Jidfjvwxe2cvyJLSX9L7pjbYW0DKcwbU+HV3B7JisI41rVcbxFx1bO+cK7ENEA5rZnTWNTESdqyzb1q1uzKEvxpgeHHYXyo/Brqf2W/lahMMvYH451YYRBrO0NP1W7q1XZD6NeXUkGY31rj7HtDwkn8CqfC4pFzKA4AkgfNJ57yTHr0qK/wAbAmMs/szGscoHL8Trxy+M09M618pPTQbiXYCMyqCGQZASWYlpLazJldZ0B9rblu0bga6rEk5NGyAsZIzZQJWIHfHlVVf4yGZIUaHXX0oEgdreWC+cRR1niGYgs3oknX6RzA93KR+BLxmtk/4npaLU22jdiCToIUCY5AamFUa93iaZ1SyJDA9/f5x9lRrxDUQw17yB8Yn1UZYzNqF035D2d9c8oy8nXCUEtAd3CrDRocvztvGBOnroTD4RS2YLqEQkkTOYsTJ5nQH11Z3ohwWOx02Oxme6o8KkJO+i7jaEXvPnQm0qG0mwf8h7pPloR6iaacIV1Dz7PfrVkhBHdPcTr69qTopgEjw1+7elnJeR/XB+Cplu9fx5TQPSG8y4ZwRHWFLY15E52PqyD21omsDlp4xP2zWY6QWesxGHww29JuUG40Gf3FDV1/FlKct9HD8uEYw12Zz8kf6B9lKt7/mDD/o/dSr0bPLoA4lcy3LGI5OozeJSFcetSvtNO6A5bONxGGbbV0POUJgjzRiagsfncM9vd7ZFxR3jZ/cSf3RQJxfU4rBYrkYt3P3CEaf/ABlPbUpWmi262eu4i4FEsdeQG+sfGD7Kx/G8UEXeRsBO55ARy5z66uMffCBmPZAHLXTkBO59dYnFXWu3M7adyjZR7PfXNKSj/To44Ob/AEAIjksSZZySSRHIdw5CAPAVK+G0kyDuDGx2/HeNKsUwqkHNy19GdfZTskg8ztEa/Cud8rs7/qjWyHhiloYAgzl57zrqY05ztrVnZwhZgxkQGBmdZKk6TsMoE8ia5gnIQwhnbXL3dxX4VY2sTCdkEHYDcE66+jHn4Ck25OxUoqiJ8LKlhoBoO49/vAHqNQth2BjkBy29njv6qt7Vj0V2jtGNZ7p05mTPeBTb1nQuTuQAeUTA595JpyTqhRabuyjxuHcqArqgkknfbw9tQ4fHmQoBLCCRoQQsg+EEEbd9QcVcHEBQ5A127Q7AhtDMbHn8a5aQWzmkkgqJPIagj2MPq1rCKSSOTkk5SbCsbb/M3Dpow8zJCVnCK0WMuDq7g77gHhHWA9++g9tZ8VtREXRDg07A9fxNW2Cw86HY6HSdwRtz3oLh6So82/mNaHAW4E+KfzqKzbeWjaljv0VT4OGEJG+YSQFnTWDMaxBOhEayBUFizbZ1NxhlI1ySNRoFMnQT3fbWtF0m8bWX5qnKFjWW2O+uh3iOYjUK5g7ZAZbbgEfPGsiZEaggRHqPnWn6Zz36KHGcOssma28HQFdyRpr6tzv6R2qWxwg5FfKTA1y6HsmASSDAEd2wjlVuz200bMIKxkEn2TEnuMa++fDcXRTkyxKQMwgkiZ7Prnn76qHphr2VK4Ngum/KRM6E6BhrEnbbeasV4ZdKGbgDRK5ZE9nQEctSNZ++pruJUMShGUgH0tddCAPZtQlnFxcKycp1EamAWGs7HMCfWKiabGn+yTCdaQUcSAplpA2EEt2jt+rG53ijrFlVCIy5Sw0JJH62pGm0684Ndu4c3QerJKTJAIh4MQdAddQfYO+pbltiOs3AkFTAIgyoUeG3qrPGL7Rf2TXTGqiagXFzASRM/GOVDAg6ann59x1NMxCiAYAJnTNoe4EjlodjOu+lDl9I8dXJJYDtHcxppqTlnTvqPqjejV8vJW2FNcggRqTAUDmdNpP49+ZsP1mKxN8RCgpbI/W/NW/YuY+qrJ8YbYuFgPzaM2YDQkABMukTmddu6edVXDvzeGBO7s1w+S/m0/iZz6q6OGCim15ObllKTSbJ8lnxpVVdb40q1M6IuJG5h3tOLqdpZZA5IWQCFuEaagnsgmNdiRRONw7NhrqkD82VuqQR4I4A3I7SGRp2fEUAbAe2RAzRoY1B8DuKssDi0i2zkZXTq3gAHtKUMqo1bZtpJ8aFaaG2qLcYw37VlmMjICB4xkcnvJZCf3vGm3U7wo8h/bWheBYO/bt5HtLkBLLnLIRmidAcwGk6rvO1H3cXYT/Vu2lP0bbMxHnq5PqC1z8nC3JtM6OP5UYxUWto7hhMRqvq+wVJh8bZWWa5bXWIBBiO+BufhFBYxLGJRUtYoKoJN1RmNxkGpKqx7QHMADv1iK7ewvDEJd8UWY9oh84JnmVChpqXx4bq/wCGseZciq6LHD4u27lVuIWgjLmAb6p10o3BWSGEgMJEAwdzqZ22+3UVhOL8TwSXgcMjMwYFWZmCLBkTPaaNO7zr0hHvb9Suuvo3Dv8AvVa4XL8nr+kT51DS2H2AADliTqQI0J2HqANBcRxPVgEA5VGY6SB81ZGYaTz5RUWIxeIHa6pQfREq4G2k9rvmPOOetLxbiN1Vc3EtqAAWnrQMucDUBtBmkbd451T4WzFc8V/Smu8RSyjO+pMiQDmAaDqdufdPhpqfgrouW5dTJUkhuySI9LwGk8j7qBvWLzW7d+2gFucxZetKmDBNxWc5rZgdpIga6ja3ThLqBlwyLzgdaIMzyuDmTVvi9Gf2+yHEGVuR+k9naB76pRVu6v8AnVUCQTI1nbUDtDx3zbVUA70sRqYRwpZUftN/Ma13CMOWZQPpJuJGjqdfUKyvBvR/ef8AnNXqdLktDq3tkhdOyQJ8fP11MoNbRouRNYhPGuMmziRDFiQIQRAnmzGYO4Gmo9tRPx1LyOVzWnnLDQC2xMHKViZIO+m3KjLHFreOTJbtKGQhgbkMQCYaJZY5aT6q0Frg9pT2lVxEaqBEQBqBJ0Ma01FJW+zJvdGOw1k6y1xhHeonzhI3g90VJiOGyZUAb6HUgRMgheU8vV3Vsxwq1yQA8iIkRty5QN+4UN/hts8t9+ymvgZTUaD2CiUwUW+jCY782cjdw9FhlYZYBWJn7YE86cnBris1wqAsHsFmzAjVtpEgSSJ07q3nCAgz2iq5rZBHZHoPJU7d4Zf3alXAWizK6KT6QnuOkeoyPWO+jK1ofT2ZnBTbQHKT35sp2OgUkxpyidjrtU+Dxskhmth8pOXNoPYdCMu09+uxq5PCbJuEPbB2ZCS2kaEDXQjf97zo1EGU2mErEAHWV2jxjb2VDinsMmZt+GNfRLtt1KugdARvpqp+iVJiO8+cQXOGPZXrQFZGyqxUknSZzKQIEmDqdQJG9ALxRuHXmw9xostL23ZS2UbAgDVjJCMs6gzz10FrpHhmtreW4hsXiUdSYKPqCcp1gwZ0/W51p9cXsqPNOLrwUGO6PX79soEa2WZSbjFMpUDQBVuEgEwx0+aIoe/0Sv3EAVrSqoVAMzEwgO/YEEszNz3571rrOKS04tdYjIxi2QwOpk5DB8DHl6qbxfEph1N9nVFHphjAby728Br3cwyi2lQNK/6YD/I+J+la+s39FKtL/n/AfpG+oaVVcvRFI8mfEmIBIHhU1njD29bcK0RngM+0aE6L6gD3k1ULcprPVKLMwzE465cMu7N5maFa5URamk1SiATYxbIwZTBH/Pq23Go3EGiOIYprhW4GaBAEmcvMAdwkHu2mBNVhNFYNplTJVgQfDYj+JV9lXSWwXejmGs521OgI9fM19HcOS21q0YYZraQJP0RXhvBcRZsOHfD9cwMjPchR+6Eg+ua3WD+UV7lxLZsKgdgmYXCSMxgGMg76zlNMtwkX/SF1SYYBDpBkk9505V5diMWFxrDOvVvlDNlO2QgabxLEd8VrunONdGtBQCuU5vDUffXmOJclyx3mTSjIcYLZuM9rQC8oA0AFt9I2jSo2a1+mH+29UOExhZddxp7Kc+JA3KjzYD41aIcaCMPxbrLr22yoomGhjOQwNAJEijMw1gyO+COXjrVIt9c7HMsFV1zLyLePiKnXGp+kX6wptAXGDxGRJ55n/mNBcUYls3fr7ajwmKts6q95UQntNMwNyY5mn8QxVksQl1GUEgEkagHQ8uVS0xpot+gt0rcu6x2J2nZh4ilf+U/FMBkt2UPfDNpG2reVV/A8XYQXC+IS2coy/OzQwJXSYkc9IMVlQoEdpfrD7DSxvwNNWbdPlMxsbWD45G+x64PlNxUj83YiRPZeTr359PZWKHPUHyM0yk4p9o0izY4vp7irjh7eSywEFkGYsJJhs8giddqbY6d41bq3Gui4QrAK6KFMxMi2FJ799wKy+HTQtoBMSdpHIczuNhpIp4K5vSOg+j/eljQ7TNpiPlIxRKHq7AhgdFefH5+gIkHzrnFvlGv3LeVbaWm0h0Zsw745eozWPdQSAGXv10+OnfzqLEAghSCCNYPupJdDpBfEeMX72t669zIpKhjoC2mg2G1RoAiRAJgL5TuR3GJ9tCKZgfSafUv/AAPbTxdlm10Gw+NaVoz8klzFkILagAB8+YSGmMo1nlqRHeaFxN53MuzOdpZixE+JNMDTJ7zXVOtC0Nu0OyDupU6lRYqQGDXSa3PEPk8fMTYuqVJ0W5II/eUHN7BVc3QbFhoyZh3oQR/EVI9lXaMU7MtVhg+D3ri5ktsV11743AG5rb9HOjS3Va01pEe20XQ57QbKI21ZD6QCso7e5ImtXjuDquFuWrRKtkbKV7Jzbj0dtQBpyqchs8Zt4ddzrRKxyFRKlcy1DTZqqQSKcGjXu8aFAp4XyqcSrPQOkLddbfKMxGQLznmfiB6q87xUhnQqMwYgyNdDtW/6DXSUfN2smgkzvEfBqqOP8Ea5fdwSC5mAP+KpVFEQf5NWVfCMA7q5VCRnO3iBQvFsObdxM6bo2h516f0N4R1FsqZYscxnyql+UfC2xicGX7KMHDkb5QUmJ5wTFaRkrsjuSj7ZaDoLgiATbInucjePCur0DwX0Dy3c98934FapWBt2yNsqxM7ZfCkg7yv8VRkwMoPk9wX0W+u3310fJ/gfoMf/ACN99a5SPpL9U/bTgRPpLP7NO2TZlF6BYIbWpB73Y8+815tx/Dpaxl22tvsKwCqoXSVU+kyGdSeVe8OIXXXb414V0tecfeGml0axroFHmaqEmHZS2hAae8+FNNSqpOcjXtNTCh7qT7No9FpjcI3YVPzgtpllYMnO7kgAkkdvQxtExVeLLSdPeJ9kzPhRGBfKjAgjmG7iJJHrn3UcnWHWM+mhAW4fWdSPI1EpUzSMbRV2rZLwwI7500351YYq6rWGJWArL1R+cT88eKx2vAhe/Uq/cy22LhFPzVZVzHwCxt6o0qgvXmcgsSTpvyA1jwFODy2Kao6jQSforH2/dTNk8a4x7P7R934ApXDsPx+NqujOxDaurTWFPOg0pDTHTSoTK3jSp4/sWX6NGOmmK/S/w1InTrFja7/CPurKUqvFGRseH9KrpxAuveUNcUW3cJqihuyxAGpEk6SYEazFScW6T4i3cZBiesUaq6rGZTqDG6mNwdQdKyeBeH89Px7KKxlk3IZdSJU+2ftqGldFpWrGtjFMk7mdY76acUv4EUJcsMu4NMiqxQsmWC3gdqkV/Ae0ffQSLoPxzNFm3t+yPhUtIdltw/iN20ItvkBM7rViePYon/Wk9+h+yqBLVG4C3FxP2h8aEiWXB6RYxFLdcwABJjuAk8vCqLi/SK5imtNcdn6stE6Rmjbf6Iq+49/oP+y38prCJoPWPg1Vigg9pn0Fw69ns2iVJm2h5c1Hj40UI/R/y/fWN4Z0rsWrdizcLC6ERSCNAQoHpE5dxvNWLdLLK6nN/CeU/S7qypgzRiP0f8v31J1n6p/h++sy/S+wsEyMwkdpNRqNs/6p93fQ56d4U/S/h7wPpeP206fYKLZrXu6bEez768O6QkHGXzlX/WfWWnR/OOXdXpF3pjhgitLZWZRplOrDNrDSNBr3V5o+Ks3sVde47Jad7jggDNqWKbzzIn11UHT2jTjineTKq1i8kjvJP2fZTvy/wPsFAnl+OZrgq3FMhSZYfljMIk5dexJg+oU5n8vx8aAmBNPN4+FZuHo0jyV2Std3J15RXBivColadTRWGwpeY2FN0lsVuT0Q9ee6kb57qKbhzd1MOCYcqnOI8JAv5SaX5QalfBt3UNdtFd6tYvoiWSJPyjw99KoKVViicmPRZMUdg8EHbtHKg1Y8/IeJqHDrHmaV68QYBqW23SLSpWw3iOLSMltAqiNRvIO87k+NaDoDettcezeUm3cXTtEFGESy+JyrPflHdWOXXWrHhmKNp1uLEqeeg9dTJaoaPQukXyfuFL2HFxOQOj67AcmPsrzTH4JrbsjKQQTodIjetvY6dtbIct1twaLOlu3prkTvP02k7iq7ENex+IN1UBMKSQIUabk9+nurPLDb6NIcTm6RBwPgYuL22iIgBQxk6tvtEj30Zw7gd1yYs50ByggouwHeO+ieKdEb1oG4biAqA2bVYkTObedY86qjirub82kyInNGafAnx2pcfKp3sfN8dwqt2aVOj1zYYR99zctD4ip06K4r9BZH7ZVv5XFWidF7YAl7pPPVInnobZo63wZAPSufWA+Cin9sfZk+KRleMdH7qWmLW7CACDkJzEt2RAMxqRzoPh/QpL1q6zsy5ArDLGshpmRyA99WXGsIi4hlS2J7GZyRmmAddJOkDetJwdMmBxL+Dx39m2I5jm3eKpStpolrFNHjl3hdvQpceChftC2TAZl1i53rHrFQnhi/TPzPmr89cyj09yJPqNa5LZVfSIIi6M3zQmeAw67ZmyQNjmHfTblsJO8IrErm7QS4UVUJN/R16xwW8u4VtZmZT/DFn0z6TD0V+YJY/wCpsBr31z/DliTcIGXN6K6CYB/1OZIHrrUAIZRrqa5LZbrABoxAuj8/ooRUB5mZ51JZfP2ldc+ZrgGcGGS2HuSBiNVdhoNhlPLWiw2ZgcIWSvWGQwSIX0iYC/6m8g+GhqWxwyz2c10kMYUjKJ1gn0u8edamxhyxRbYZswcKgeWZS4/ND8/rcUM7Zu4r3AVJiOFXs7YcJc602lJCkhpUEI4BvEgBSqnTUhjuaVi2ZXpJwI4W4i6lXTMJ8yCPgfXVGyxXr3ylcOzWsLdKkMMyMCNi6htY7ih9teaYvCaacqlSNUrQJhsEzgtoFBgsxgT3CASx8ADE60QeGd1xJ8QwHqMT7QKMbDu2Ftm3qULhlGrQWJDgc+4xqAq8piot3bhOjMfXNXskkxWDe3qR2SYDDVT6xsY1gwahtXSp5jxBj4VreGYR0unD4pMmYHNPosg1Lhhp2fSkbQDyrKNZNK15Kim+i34feuucqujH5qvu3gGG58CaKfGZDF6yy+I7S+3b3mgOGcJuOoKKWJPLQLBiSTsZB9lav/DMUE7VxHMaiQSfrKJ9tcnLy8cXTaO3h4OWcbSKi3csv6Lr5HQ+/emfkadtmjKCF15+EczJIio7/UyweyQ6ySFGWY1MqTpprprExQC8ZyABba6ejmlgo/VWdD4kk/AXHjtXEy5JYvGQX+RW/wBGf4f66VAf4/e70+ov3UqvCZllH0HYfhCjV3LHuTQfWO/kADXOK4NDbJRFUpB03I5yTqdwde40RgcRntg8xofMaUy9jramCcx1BA10O4NO3YqsoUuLlyka9/r+6npeABAEzXcgqfC4XO6roJIEnbXy3ptoaixcO4a1xhyHfWibGvgLgFu462nWY9IFhoxgiAdj66Pt8MS2BkZj4MVJ/h09lVfSVXuWxICqktIMzMCPhUZRnplrKDySIuNdJzeXLLMfGY9Ukx6oo3obZ625ZzEQryxO3Zlx8AKxSpWo6P4HrUa0WCKxUZiJC9oaxzo+uMVSKnzTnuWkvR7GGX6S+0Vw3rY3dB+8Ky+L+TK0MM/V3Xe+BKFsoRiB6OWNAdpkkGPKvNhwTE/oD7qyXB+xfamb+4esxOIdTIzhQQdDlUDT763XRzBK2DVXUMrlyQdj2iNfq1gOj+Fe3h1DjK3MHw0HuArVYDp5gLFtbN28UuIArKbbnXeZVSIMz661S8HPN2XT9HcMZnD2jKhTKjUCIHl2R7BTL3R/DHNOHtdv0uwNdc2sjXUTVa3ylcN/7j/8dz+mon+Unhp/67f7dz+mqpkB/wDlfB/9tZ/20/pqS10bwqmVw9pT3i2g3EH5vcTVOflJ4cNrrnytsP5orqfKZw7ncuDxNtj/ACzRUgL+zwDDAACxa0zfMX5whuXMAA1J/gGGAj8ntRBX0F2JLEbbSSfXVCnym8NH/Xb/AG7n9NSn5TuGfpn/ANq5/TRixWEdKuHK2DKKoC2yhVQIAAOXQcoVjXmHEcBl1Ar0G9094ffBs2rju9zsKvVuNW0GrAAAb+qs1jrb2y/WK9xT6GUyo19AiJtk7ZtV5nLzVey4yMnhnUIAOUnyM/fp6qIGLyuLgCZx88orN7WBNUXFCyMtxFyJczkLJOQq5VlkkzsG/foI8QaK0SdA0m7NgnFLtwqhbrMpkIw7BAiAVWAw8D3UBx9Va4CLK2WjtoghJ5QvzOenlT+g+ENxrtx1lQAATtmJnTxj41ccSwiqrNEBQT7KmSHF1LRU9EuMiw7KxBQsZVtu6QeR08viPTbHFMPcGZmUnQkMIBgAbjs8uRrwQXSD40XZ4k6eizDyMVzcvxcnkj0uP5HG4pS015R6F03GDVVu23VrqsICSQ3gzDsiN9TOhjnXmHVUW2KNwyzE+ZmuEVvxpwjic3K4zdp2C5K7U2WlV5GX1o9Nt9GMGojqnIO46y5B8wGFEWuC4Uejhbf7wn+Ympmvt+PxNS2EYnn8PjSOe2GYHg9giDhbBHd1afdVbxfoFZa4Hts1lfnIozCdNVzeh/xtz1PC7Tc5p+JaT+Px31nezRN0Y1egNr9Pf/g/ppmL6DWEQ58VdC85yctROnhPfV7ieLAE27Cdbc5kegnix2quW3cuXOV5x84g9XbM8hs0Dv5xpzqhZMq+HdCMK+T87eBctkBC6hQTPo6AgSDtVtxLonaw9ki3cuZ2OUFo00JnQciBWj4bw1EbOxL3Tu7fYJ0GnuoDpZiYa0nmx+A+2ob3ZalKSpsx2CvcRxhe0pFvqwJa6zKm8DLlXtd9aLEcAxLW7YTFW7d1YzOrHtdkhuY0JM+qrro2kW3f6Rj1KP7mrIXPE+oz9s1pZDRhn6M44jXiJ17mb+quL0Qxx0/xC7tOlxgfDY1vM5GuvmZNUq4IX+suflDrcdlIVXKC2qPGWAZBcqQW3jQbUWIof8p4+IGPuetz91QXOgl5vSNgtuztOZidyxCaknUnxra4PFOQ63AQy7GVOYEb6QDqGHLbaqnoNiGuYYu7lz1jQS7voFUb3HY9/ONaT2UnRlMF0LdyQj2SRBghhoSRvk8D7q1vCOjlpbSpetWXuAsZyqZHL0lnwqbgBl3/AGE5R85zI7h4Vd223Gu55H402K7K4dH8L/29n/bT7q6eAYXb8ns/7a/dR3WLOXMM0TEax3x3U8EUgALfBcOplbFpW5EIAR7K7f4dbYEFAZ8/vo7SuNHcaQHm3TPotaXD3Llq2qugzSJ2BltyeU15lawlx/Qtu3LsqW+Ar6PxWFW4jIw0ZWUz3MCDVH0fwoW2bY3tsV25GHHubL6qtSoL0YXolhcXaUIbNxrb6wRlyn96tPjujt69bZQUt5huxmPqqZ9tahEgxp+PCZqVHOnwpOVkruzy7EfJfdgkYi2T3ZWA9uvwqjfoZfLMqqAVLek3pAH0lgagyvIc69xIJHL2f3rNcbuvYZLqorqH1lirFW7LLAU5jqCNRsOY1M2WnfZ5Z/lHFL8xT5N94p69E8af+ifr2/669hSyXQM6ZCZOU6kAkwDpvEV1bYBUfSYKPM9/hpRk2NSro8e/yhjf0B+vb/qrlep/4n/6f8X/AMa7RsWbKlLhqzwaOYPLyoS0CCB2ZJAED8eJq4uHKABSkzOKLRLgS2SSC0bDf2CqRrF29/qTbT6C+k3n3ev3VKHP0vdNT2NT84+qPuqKZpaBU4O2XLl6q0uuVSJbxJB9+/lVphMKqqFthQBsKfj3C2oG7ECo8IIA39/30bB0HWLJGp+ysrxvht65iGYW2KgBVOmsevvJrTZzG9cV5I0pNDi6IOH4c27SJl1yyRpoSZ+2pwn6sfjwNOvuARmIHiTFQI6kx1gPl94q4u0J9ixKaap65rOWMNetq9woyWySwNsKTz1YNJAPZ1gDc85q36Q3erw918xOVCSNtI7XumguCXrl2yp6+4okkidQTuA0SV3jvEb0xeAvB4S41pyDnuXFhTnnSDlgqFEdomQOdQdD+HXcNh+qvwbisxbKZEGcpBjaB7QaHx5KYO+y3irWyz23SFPZUEbD6ZYHly76M6L52w4u3Lj3blySWeNgSFAAgARrp3mgKAuGOZcqSDlt7HXXrN+86bjSrBLr83b21XcKBOf9iz3f+qPxGndRTvlBYxoJrDlvKkdHHWNsrOMcNa/cFy3cIuW4XciOcBh2l38vCtXwq67WwbnpSQaz3CwxTMTqxnXu5e6rnAhoIDMB+rlj+IE8qcJO6smcVjZZUqDL/wDqXPYn9FORidnuH1LH8lbGIUap7XYxbryuJI80M+8Ofq0zpFexVu2rYVkZ84DC8OzlIOoyAGZA376p8Pj7zdVdxIth0cBurBC5WJQntGfRcn1Un0CNU8Dv/H4FNz93PXT7uVTEfjxprGgRxW86gxA59xn2VNNNuCRQAruokVAqElYMZXVvPcR4elMjup1htCp5fA/3+NOsqc3rHxFAjIda/wBAe0/00qM/Iz4fj1UquwHcKs5rhbkogazqf7fGjXcydT7vupYJMlsHm3aPr290Coyw7vcfsqO2PpUdznvP1vuAovApJ1HtzE0GLh/H9zVpw7UjX3ihghnFGm4lv6Ik+uiLQEf3j4iq1bvWXXaJ10+AqxVvD3x9lIbJSoP/ACK7bXX/AI+yousHIe8VLZafbUsaBeJY5LRGeddoAO3n51WPx5OSMfML9+/31D0laXUdwJ9pj7KomSeYrJ8jTpHRHji1bLLiPEjfR7K2/TUoTOsERsR586i4FwC6oUMMi5QDEMxMyW1EK3KddD4VNwC1+eQ7wDoI7iOZjnWtQKOXsA5bVtxybVsy5IqLpGd6UWVTh962gAAt5QJAAlgO7vPnrVh0atm3grCsIIspO2nYk0F03w73MFdt2bZZybcBRrAuITtrynyq5sqFs5QCMtuO7ZfMfGtTPwU/BUJD5Wy9i0Zyl+dzkCDz7/UKM4jg2KFWYNmgCFj4sai6OD0/2Lfxfx+z1nkbiLqvcyZZyamQImNNyJ51DinKxqTqjmH4cFUAmI02/vTriFB2G1J5AePeaRRfoKdtOz5/Spl9AV7IXnJA8Dv2jzNRKCStFxk20mQ9a7cyO+VGvrikbrCNf5R/7aiWz3keyfxtXbqhtJ901hk/Z0Yr0cuXLjW7gfI0DN2TMZTJPu2rP4h8ylSdCCPaIrT4JROXUggg6RuKxl67BKndZB8xofhW0HaMJxqRu+GYnrLVu4dyoJ8DEN7waJNZropxJFtOj3EXI5gswUQ/a5n6RYVZXekOEX0sVYn/AO4p+BrRGUlssTXCaz+J6a4FN8Sh/YDN/KpFVWJ+UvCL6C3bniFVR/EwPup0xUaxzlYNy2PkaddvFAzAFiATA3JAmB51gLvynWjp+TvHf1gn2Zftqxw/ygYNkUu1xW2KFCTptqJB08aMWFEX+Zj/ANte9n/wpU//AD3gfpP/ALZpU6foKNFiDyockcxPmake0x1Mev4bVF1B7wPACoVDdj0gnQD1a/CrPPktM3cpjSNToKrsPhf1jRXEuzbS2Ce0ST5AR9tJsaRFwpeyPbzq0j8ZqgwVoAAUUbYobFREfx2hUlvYVxrfl7KcdB6qlspIynG3m6fAAe6ftoECtViMNanM6rJ3LA8v7VA5w40K2NO+2v2nWp+lvdmy5ktUA9Hk/OMSJhO6eYj7a0iwfm+6qfDYzDWy2S5h7RbTZUJiYntDNvTjxuwpGfFYcd/5xR8XrWEMVRlOWTsuVQfR91R4pQEYCB2W9fZNV/8AmXCf93h/91P6qZiOkuDKMPyqwSVI/wBRNdPOqpkHOj29z9m3/wC78faaPZG55T/4ydPrVUcBxNpusHWWmVguzKwIgg7HbzA3G9XN5g0RB8RB/wDcDTfYhwCndT7CP+KgxVxVUsVaBDbHYHXl3TTxZEiRpJ5KBPfqT+AKc1lCCsSDOkp8O77qTQ1ozVrpLgWMLdM93V3PtSKLXidk7NP/AI3/AKat0wiDZCNeSJ934inG1ppn35KJ08h41n9UTb7n6KZ+LWkIJYiSI/Nv6vm1m+kVrJiLsDQnPt9IBj3cya9AtW9Nm/en4Vi+ndn85aeD2kK7fQb3+n7qcYKInNyZXYHh2HvW269LbHNlGZipACz2Wzgrqe+DG1VfEOhWFMm1iRbM7Oyuuu2ohgPGGoZMYZZT81oHkQG/mLVwYqedD5HHSKXGnso8Z0du22AHV3e7q3Dz4QO17RVaUU/qnx29tbJLkMrSd9+7uPurNY9wWK5FXLK6fOg7mrhNy7JlxpdADYc05bPfXYjbT4Uut7xWtshxo51IpU7rV7/j91KlsVI2r/KTcP8A0Lf1m+6hLvygXz6KWV/dcn+b7KxlKjCIWa3/AD7ixs6Dytj7aH4h02xd4jNcywI7ChSdZ/ERWapTTxQWW69I8SDIxGI/3H/qolOmWNG2Ju+tp/mBrPzSEUYoLZoW6Z40/wD1Nz2gfBahTpJi863BiLpcbFnZh5EEwR4ERVOMveams3EB1LUml4RSfsub3DBdZrj+m5LtAO7GTv4muDgSDefbFDnidv8AX9g++mjiiDY3PYv31nU/Zf4LwENwhB//AEPuplzh9sbT+PMimDi67Tc9i108XXkbnhotKphlAQ4ekc/aB9pph4evL+Y/01GeIr+t7F+w11OKAbA+wffTan4EpR8kj8NQd/48xTrfClI2J9n2mov8SSZIJ57D766vE7f0W9g+006mNuAYnAFYSM3u+yaf/lteZuD93+1Q2+NW1EBD49kfY1TDj9vQ5Wn9kf11m/t8Fr6/J3/AEHou48Tp8FqQcGYf9Vx5M39NRnpDbjZx+7/+yujpGnfc9i/fRfL6CuP2TnhjR/8A6bnhNyB/FFTYbDNbkNdDzydg3I7AvQo45Z77gPPKuU+0NQ13itmDlNyeRPa9z5hTWb0/+CeC6CeIYRmMq6rMTlVYJHkeWY+OtVN3BP8ATJ9RH21J/iinfLpt2PsBgVy7jLZ5n6v31ccloh4vYE+FYc5PrqVlOmnKpBi7cbfH7qY+LQ7ChuT8FJRXkQt86gdK6cQKYbo/AppMHKJzq/ClXeu8fdSp7J/EHpzUqVWYja5SpUwFSpUqBipUqVACrtKlQDOUqVKgQqVKlQAqVKlQAqVKlQAqVKlQAq7SpUDFSNKlSGKuUqVBJ2lSpUFCpUqVAj//2Q==" alt="Online Study Image 2">
            </div>
            <!-- Add more slides with different images as needed -->
        </div>
    </div>
</main>

<footer class="footer">
    <!-- Add links to important pages -->
    <p>©StudCart.inc</p>
</footer>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Image slider functionality
        const imageSlider = document.getElementById('image-slider');
        let currentIndex = 0;

        setInterval(() => {
            currentIndex = (currentIndex + 1) % imageSlider.children.length;
            updateSlider();
        }, 2000);

        function updateSlider() {
            const transformValue = `translateX(${-currentIndex * 100}%)`;
            imageSlider.style.transform = transformValue;
        }
    });
</script>

</body>
</html>
<?php /**PATH D:\Car\practice\resources\views/estoreconn.blade.php ENDPATH**/ ?>