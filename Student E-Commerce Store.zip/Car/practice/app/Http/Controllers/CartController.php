<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class CartController extends Controller
{
    /**
     * Add a product to the cart.
     *
     * @param  int  $productId
     * @return \Illuminate\Http\Response
     */
    public function addToCart($productId)
    {
        // Retrieve the product from the database
        $product = Product::findOrFail($productId);

        // Get the current cart from the session
        $cart = session()->get('cart', []);

        // Check if the product is already in the cart
        if (isset($cart[$productId])) {
            // Increment the quantity if the product is already in the cart
            $cart[$productId]['quantity']++;
        } else {
            // Add the product to the cart with a quantity of 1
            $cart[$productId] = [
                'id' => $product->id,
                'name' => $product->name,
                'description' => $product->description,
                'price' => $product->price,
                'quantity' => 1,
            ];
        }

        // Save the updated cart back to the session
        session()->put('cart', $cart);

        return redirect()->back()->with('success', 'Product added to cart');
    }

    /**
     * View the contents of the cart.
     *
     * @return \Illuminate\Http\Response
     */
    public function viewCart()
    {
        // Get the current cart from the session
        $cart = session()->get('cart', []);

        return view('cart', compact('cart'));
    }

    /**
     * Process the purchase (Buy Now).
     *
     * @return \Illuminate\Http\Response
     */
    public function buyNow()
    {
        // Get the current cart from the session
        $cart = session()->get('cart', []);

        // Additional logic to process the purchase can be added here
        // For example, updating the database with the order details, clearing the cart, etc.

        // Clear the cart after processing the purchase
        session()->forget('cart');

        return view('thankyou');
    }
}

