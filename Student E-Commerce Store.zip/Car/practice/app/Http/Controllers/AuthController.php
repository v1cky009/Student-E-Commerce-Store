<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Register;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:registers|max:255',
            'password' => 'required|string|min:8|confirmed',
        ]);

        Register::create([
            'name' => $validatedData['name'],
            'email' => $validatedData['email'],
            'password' => bcrypt($validatedData['password']),
        ]);

        return redirect('/login')->with('success', 'Registration successful! Please log in.');
    }

    function login(Request $req)
    {
        $user= User::where('email',$req->input('email'))->get();
        if(Crypt::decrypt($user[0]->password)==req->input('password'))
        {
            $req->session()->put('user',$user[0]->name);
            return redirect('/estoreconn');
        }

    }
}
