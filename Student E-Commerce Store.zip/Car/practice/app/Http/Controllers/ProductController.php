<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function sellForm()
    {
        return view('sell');
    }

    public function store(Request $request)
    {
        // Validate the input
        $request->validate([
            // Validation rules
        ]);
    
        // Upload and store the image
        $fileName = time() . $request->file('file')->getClientOriginalName();
        $path = $request->file('file')->storeAs('images', $fileName, 'public');
        $picturePath = '/storage/' . $path;
    
        // Create a new product and save it to the database
        Product::create([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'price' => $request->input('price'),
            'picture' => $picturePath,
        ]);
    
        // Redirect back to the sell form with a success message
        return redirect()->route('sell.form')->with('success', 'Product added successfully!');
    }
    

    public function products()
    {
        // Retrieve all products from the database
        $products = Product::all();

        return view('products', ['products' => $products]);
    }
}
